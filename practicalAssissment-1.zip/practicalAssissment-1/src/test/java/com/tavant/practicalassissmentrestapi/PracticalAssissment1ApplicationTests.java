package com.tavant.practicalassissmentrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticalAssissment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
