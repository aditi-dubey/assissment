package com.tavant.practicalassissmentrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticalAssissment1Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticalAssissment1Application.class, args);
	}

}
